package com.nazmul.routeradmin;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.Intent;
import android.net.Uri;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(11, 16, 32), panel = Color.rgb(22, 29, 50), pink = Color.rgb(255, 23, 100);
    private EditText ipField;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(20), dp(28), dp(20), dp(24)); scroll.addView(root);
        TextView brand = text("ROUTER ADMIN", 13, pink, true); brand.setLetterSpacing(.12f); root.addView(brand);
        TextView title = text("মো নাজমুল হক লিমন", 25, Color.WHITE, true); title.setPadding(0, dp(8), 0, dp(6)); root.addView(title);
        root.addView(text("রাউটারের অ্যাডমিন পেজ সহজেই খুলুন", 14, Color.LTGRAY, false));
        LinearLayout card = new LinearLayout(this); card.setOrientation(1); card.setPadding(dp(18), dp(20), dp(18), dp(20)); card.setBackground(roundRect(panel, dp(20)));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = dp(26); root.addView(card, cp);
        card.addView(text("ROUTER GATEWAY IP", 12, Color.LTGRAY, true));
        ipField = new EditText(this); ipField.setSingleLine(true); ipField.setText("192.168.1.1"); ipField.setHint("যেমন: 192.168.1.1");
        ipField.setTextColor(Color.WHITE); ipField.setHintTextColor(Color.GRAY); ipField.setTextSize(20); ipField.setPadding(dp(12), dp(12), dp(12), dp(12)); ipField.setBackground(roundRect(Color.rgb(34,42,67), dp(12)));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.topMargin = dp(12); card.addView(ipField, ip);
        Button open = button("Open Router Admin", pink); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54)); bp.topMargin = dp(18); card.addView(open, bp);
        open.setOnClickListener(v -> openRouter());
        Button copy = button("Copy Gateway IP", Color.rgb(45,55,82)); LinearLayout.LayoutParams bp2 = new LinearLayout.LayoutParams(-1, dp(52)); bp2.topMargin = dp(10); card.addView(copy, bp2);
        copy.setOnClickListener(v -> { String s=ipField.getText().toString().trim(); ((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Gateway IP",s)); Toast.makeText(this,"IP কপি হয়েছে",Toast.LENGTH_SHORT).show(); });
        TextView note=text("টিপস: আপনার রাউটারের সঠিক Gateway IP লিখুন। অ্যাডমিন পেজ খুলতে রাউটারের Wi‑Fi-তে সংযুক্ত থাকতে হতে পারে।",13,Color.rgb(174,184,207),false); note.setPadding(dp(4),dp(20),dp(4),0); root.addView(note);
        TextView footer=text("Made by মো নাজমুল হক লিমন",12,Color.GRAY,false); footer.setGravity(Gravity.CENTER); footer.setPadding(0,dp(32),0,0); root.addView(footer);
        setContentView(scroll);
    }
    private void openRouter() {
        String a=ipField.getText().toString().trim(); if(a.isEmpty()){ipField.setError("Gateway IP লিখুন");return;}
        if(!a.startsWith("http://")&&!a.startsWith("https://")) a="http://"+a;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(a))); }
        catch(Exception e){Toast.makeText(this,"এই ঠিকানাটি খোলা যাচ্ছে না",Toast.LENGTH_LONG).show();}
    }
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setBackground(roundRect(color,dp(14)));return b;}
    private android.graphics.drawable.GradientDrawable roundRect(int c,int r){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(c);d.setCornerRadius(r);return d;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}
